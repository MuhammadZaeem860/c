﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.String;
namespace Assignment_algorithms
{
    class Program
    {

        // Function names:
        // 1. ProcessQuestion4
        // 2. SplitStringIntoAlphabetGroups
        // 3. GetUniqueGroups
        // 4. CalculateResult
 
     static string ProcessQuestion4()
     {
        Console.WriteLine("Welcome, I would like you to enter the string for Question-4: ");
        string inputString = Console.ReadLine();

        // Step 1: Get the unique groups of consecutive characters with the same starting character
        List<string> newGroups = GetUniqueGroups(inputString);

        // Step 2: Calculate the result based on the number of uppercase and lowercase characters in each group
        int totalResult = CalculateResult(newGroups);

        // Display the final result
        Console.WriteLine("\n" + totalResult + "\n");
        Console.WriteLine("\n\nIF, you want to continue press any key");
        Console.ReadKey();
        return inputString;
     }

     // Split the input string into groups of consecutive characters with the same starting character
     public static List<string> SplitStringIntoAlphabetGroups(string inputString)
     {
        var result = new List<string>();
        var currentGroup = "";

        foreach (var character in inputString)
        {
            if (currentGroup == "" || char.ToLower(currentGroup[0]) == char.ToLower(character))
            {
                currentGroup += character;
            }
            else
            {
                result.Add(currentGroup);
                currentGroup = character.ToString();
            }
        }

        result.Add(currentGroup);

        return result;
     }

      // Get the unique groups of consecutive characters with the same starting character
     public static List<string> GetUniqueGroups(string inputString)
     {
        List<string> groups = SplitStringIntoAlphabetGroups(inputString);
        List<string> newGroups = new List<string>();
        
        for (int i = 0; i < groups.Count; i++)
        {
            string currentGroup = groups[i];
            bool isUniqueGroup = true;

            for (int j = i + 1; j < groups.Count; j++)
            {
                if (Char.ToLower(groups[i][0]) == Char.ToLower(groups[j][0]))
                {
                    currentGroup = currentGroup + groups[j];
                }
            }

            for (int k = 0; k < newGroups.Count; k++)
            {
                if (Char.ToLower(newGroups[k][0]) == Char.ToLower(groups[i][0]))
                {
                    isUniqueGroup = false;
                }
            }

            if (isUniqueGroup)
            {
                newGroups.Add(currentGroup);
            }
        }

        return newGroups;
     }

     // Calculate the result based on the number of uppercase and lowercase characters in each group
     public static int CalculateResult(List<string> groups)
     {
        int totalResult = 0;
        int lowercaseCount = 0;
        int uppercaseCount = 0;

        foreach (var group in groups)
        {
            foreach (char character in group)
            {
                if (Char.IsUpper(character))
                {
                    lowercaseCount++;
                }
                else
                {
                    uppercaseCount++;
                }
            }

            totalResult += (lowercaseCount * uppercaseCount);
            lowercaseCount = 0;
            uppercaseCount = 0;
        }

        return totalResult;
     }

        // Function names:
       // 1. ProcessQuestion5
       // 2. GetSumInRange

    static void ProcessQuestion5()
    {
        int[] numbers = { 99, 91, 75, 82, 74, 5, 2, 15, 20, 64, 91, 50, 19, 47, 8, 85, 57, 26, 1, 95, 16, 3, 78, 1, 76, 64, 69, 90, 53, 15, 60, 86, 76, 8, 60, 10, 92, 21, 41, 80, 94, 89, 50, 20, 76, 12, 19, 39, 17, 48, 71, 16, 2, 55, 83, 97, 13, 75, 6, 11, 37, 12, 63, 6, 4, 6, 74, 12, 87, 99, 93, 37, 85, 21, 1, 28, 54, 59, 25, 65, 46, 31, 74, 5, 45, 45, 85, 22, 25, 64, 97, 18, 15, 31, 44, 82, 26, 44, 16, 70, 38, 7, 52, 18, 55, 34, 31, 81, 54, 56, 43, 55, 50, 42, 65, 7, 39, 59, 62, 60, 22, 53, 87, 24, 2, 76, 22, 55, 78, 20, 2, 10, 43, 55, 27, 39, 79, 56, 50, 11, 14, 4, 68, 70, 21, 43, 68, 74, 66, 38, 44, 68, 83, 57, 49, 86, 20, 28, 16, 80, 13, 77, 3, 35, 54, 34, 12, 96, 16, 27, 28, 83, 10, 52, 46, 18, 86, 18, 4, 60, 8, 49, 89, 41, 77, 34, 27, 87, 7, 42, 19, 51, 41, 70, 98, 37, 2, 34, 16, 87, 32, 73, 59, 40, 10, 61, 59, 32, 11, 31, 1, 3, 25, 57, 73, 65, 89, 63, 59, 21, 7, 26, 89, 74, 8, 77, 43, 40, 54, 9, 17, 52, 2, 17, 29, 35, 90, 49, 31, 16, 76, 96, 76, 76, 42, 16, 27, 84, 98, 33, 49, 40, 76, 96, 80, 7, 84, 85, 33, 33, 19, 19, 78, 2, 15, 49, 2, 8, 28, 38, 75, 40, 32, 43, 45, 12, 50, 14, 33, 92, 51, 59, 42, 21, 61, 77, 77, 6, 37, 23, 51, 6, 17, 98, 97, 57, 19, 74, 61, 93, 14, 20, 57, 60, 59, 10, 8, 33, 51, 69, 57, 71, 52, 41, 83, 61, 78, 57, 42, 38, 72, 96, 71, 6, 88, 69, 23, 34, 47, 89, 93, 76, 53, 41, 78, 31, 3, 83, 63, 51, 70, 45, 55, 68, 66, 81, 55, 77, 16, 37, 80, 62, 33, 24, 21, 19, 49, 51, 73, 90, 87, 75, 87, 63, 77, 82, 18, 12, 63, 52, 58, 95, 94, 91, 69, 28, 41, 3, 40, 8, 15, 47, 19, 10, 9, 31, 44, 30, 20, 60, 83, 52, 10, 74, 65, 95, 58, 93, 92, 85, 63, 44, 14, 64, 79, 85, 68, 42, 55, 93, 78, 46, 12, 66, 75, 40, 57, 77, 54, 46, 38, 89, 92, 3, 70, 7, 86, 21, 27, 74, 70, 49, 12, 55, 45, 72, 34, 55, 32, 25, 64, 3, 75, 27, 83, 37, 40, 45, 99, 25, 39, 82, 39, 47, 48, 75, 52, 12, 94, 73, 100, 48, 15, 82, 24, 29, 35, 57, 21, 3, 7, 2, 46, 30, 83, 36, 14, 66, 20, 33, 67, 42, 22, 2, 35, 89, 10, 65, 8, 71, 21, 23, 62, 60, 25, 16, 88, 94, 4, 55 };
        int min = 25;
        int max = 75;

        Console.WriteLine("Question No.5");

        // Initialize an array of integers

        // Get the sum of integers within the range [25, 75] (inclusive)
        int sumInRange = GetSumInRange(numbers, min, max);

        // Display the sum
        Console.WriteLine("The sum of all integers between 25 and 75 inclusive is: " + sumInRange);
        Console.WriteLine("\n\nIF you want to continue kindly press any key");
        Console.ReadKey();
    }

    // Function to get the sum of integers within a specified range
    static int GetSumInRange(int[] array, int minRange, int maxRange)
    {
        int sum = 0;

        // Iterate through each element in the array
        foreach (int number in array)
        {
            // Check if the number is within the specified range [minRange, maxRange]
            if (number >= minRange && number <= maxRange)
            {
                // Add the number to the sum
                sum += number;
            }
        }

        return sum;
    }



     // Function names:
    // 1. ProcessQuestion6
    // 2. CountOccurrencesInRange

    static List<int> ProcessQuestion6()
    {
        List<int> numbers = new List<int>();

        Console.WriteLine("Please enter the lower limit for Q No.6 :");
        int lowerLimit = int.Parse(Console.ReadLine());
        Console.WriteLine("Please enter the upper limit for Q No.6 :");
        int upperLimit = int.Parse(Console.ReadLine());

        // Get the counts of Biffs, Baffs, Boffs, and other numbers within the specified range
        int biffsCount, baffsCount, boffsCount, otherNumbersCount;
        CountOccurrencesInRange(lowerLimit, upperLimit, out biffsCount, out baffsCount, out boffsCount, out otherNumbersCount);

        numbers.Add(lowerLimit);
        numbers.Add(upperLimit);
        numbers.Add(biffsCount);
        numbers.Add(baffsCount);
        numbers.Add(boffsCount);
        numbers.Add(otherNumbersCount);

        // Display the counts
        Console.WriteLine("\n\n " + boffsCount + " Biffs , " + baffsCount + " Baffs , " + biffsCount + " Boffs , " + otherNumbersCount + " numbers.\n");
        Console.WriteLine("\n\nIF you want to continue kindly press any key");
        Console.ReadKey();

        return numbers;
    }

    // Function to count the occurrences of Biffs, Baffs, Boffs, and other numbers in the given range
    static void CountOccurrencesInRange(int lowerLimit, int upperLimit, out int biffsCount, out int baffsCount, out int boffsCount, out int othersCount)
    {
        biffsCount = 0;
        baffsCount = 0;
        boffsCount = 0;
        othersCount = 0;

        // Iterate through each number in the range [lowerLimit, upperLimit]
        for (int num = lowerLimit; num <= upperLimit; num++)
        {
            if (num % 2 == 0)
            {
                if (num % 3 == 0 && num % 8 != 0)
                {
                    // Count Biffs
                    biffsCount++;
                }
                else if (num % 8 == 0 && num % 3 != 0)
                {
                    // Count Baffs
                    baffsCount++;
                }
                else if (num % 8 == 0 && num % 3 == 0)
                {
                    // Count Boffs
                    boffsCount++;
                }
                else
                {
                    // Count other numbers
                    othersCount++;
                }
            }
        }
    }
        // Functions:
        // 1. ProcessQuestion7 - Performs Question 7
        // 2. GetMaxColumnSum - Calculates the maximum sum of columns

        static void ProcessQuestion7()
        {
            int[,] numbers = { { 96, 81, 48, 62, 47, -91, -97, -71, -62, 26, 81, -1, -63, -8, -85, 69, 13, -49, -99, 88, -69, -96, 55, -100, 50, 27, 37, 79, 4, -72 }, { 19, 70, 51, -86, 18, -82, 83, -59, -19, 59, 86, 77, -2, -62, 51, -78, -64, -24, -68, -5, 40, -70, -98, 9, 64, 92, -75, 48, -89, -80 }, { -28, -77, 25, -90, -94, -89, 47, -77, 73, 97, 85, -28, 69, -59, -99, -46, 6, 17, -51, 28, -10, -40, 47, -92, -12, -12, 68, -58, -51, 26 }, { 93, -65, -71, -39, -14, 62, -49, -13, -69, 39, -25, -87, 2, -65, 9, -33, -39, 60, 7, 10, -15, 8, -1, -17, 29, -88, -24, 17, 22, 18 }, { -57, 4, 73, -53, -97, 50, -58, 8, 55, -62, -98, -82, -15, 9, -48, -23, 57, 11, -2, -80, -74, -93, 34, 39, -60, -16, 35, 46, 31, -26 }, { -14, 34, 64, 13, -4, 70, -61, -45, -69, 59, -75, 52, -95, -32, 7, -33, -78, 90, -70, -48, -45, 64, -82, 2, -9, -65, 70, -66, -94, 19 }, { -86, -4, 76, -20, 52, -33, -47, 72, -88, -18, -63, 1, -20, 39, 95, -27, -98, -34, -69, 73, -38, 45, 16, -21, -81, 21, 16, -38, -79, -39 }, { -100, -95, -52, 12, 44, 29, 76, 24, 16, -60, -87, -50, 77, 47, -85, 53, -16, -22, 7, -83, -68, 3, -98, -67, -43, -32, 79, -3, -39, -70 }, { 50, 91, 51, 50, -18, -69, -47, 67, 95, -35, -3, -22, 50, 91, 59, -88, 67, 68, -36, -35, -63, -63, 54, -97, -71, -4, -97, -86, -45, -25 }, { 49, -22, -38, -15, -11, -78, -2, -73, -35, 83, 0, 16, -17, -59, 20, 53, 53, -89, -27, -56, 1, -89, -68, 95, 93, 13, -64, 47, 21, 85 }, { -73, -62, 12, 19, 16, -82, -85, -36, 1, 37, 13, 40, 2, -20, 65, 20, 54, 13, -17, -25, 43, 91, 41, -90, 74, 37, -55, -34, -8, 76 }, { 85, 51, 5, -20, 55, -39, -96, 64, 25, 1, 38, -12, 9, 35, 31, 60, 8, 52, -70, -28, 59, 23, -36, -54, -59, -64, -4, 1, 45, 78 }, { 72, 48, 72, 24, 52, 62, -65, -78, 24, 3, 15, 89, 87, 81, 36, -45, -19, -95, -22, -86, -71, -7, -64, -81, -83, -39, -13, -42, -62, 19 }, { 64, 2, -81, 46, 28, 89, 15, 85, 83, 69, 24, -14, -73, 26, 57, 69, 35, -18, 9, 85, 54, -9, -77, 31, 49, -21, 12, 52, 7, -10 }, { -25, 76, 83, -95, 38, -88, 70, -59, -47, 47, 39, -4, -78, 9, -11, 43, -34, 9, -38, -52, 26, -96, 49, -48, 65, -27, -21, -12, 97, -51 }, { -23, 62, -23, -7, -6, 48, 2, -78, 87, 44, 98, -6, -71, 62, -54, -43, -31, 13, -59, -95, -88, -98, -10, -41, 64, -30, -73, 30, -61, -35 }, { 33, -18, -57, -97, -31, 76, -81, 28, -86, 40, -60, -56, 22, 18, -51, -69, 75, 86, -94, 8, -96, 65, -54, 91, -64, -25, -28, -82, 29, -76 }, { 21, 72, 82, 22, -89, 15, -49, -75, -7, -31, -63, 40, -1, 1, 65, 68, -20, 72, -91, 32, -6, -60, 23, 31, -40, 67, -64, -49, 66, 94 }, { 4, -100, 99, 90, -81, -33, -39, 99, 7, 34, 80, 50, -7, 37, -30, -36, -34, 44, -75, -32, 95, 0, -91, 96, 29, -20, -52, -49, -38, -56 }, { -21, 99, -42, -2, 65, -63, 40, 8, -19, -3, 7, -20, -36, -26, 52, 44, 47, 86, -40, 95, 0, -9, -75, -2, 98, -97, 91, -97, -40, 38 }, { -81, -90, 36, -38, -45, 81, -9, 94, 72, -67, 24, 58, -38, 28, 60, 14, -65, 34, -56, 85, 33, -38, 90, -34, 43, 87, 73, 59, 0, 61 }, { -55, 36, -52, 43, -22, -4, 43, -99, -81, 70, -48, 52, -87, -74, -29, 42, -72, -3, 37, -16, 68, -44, 59, -25, -95, 56, -81, -30, 19, -33 }, { -92, 31, -6, -89, 88, 87, 10, 19, -51, -36, 70, -67, 14, -27, 33, 80, -52, 64, 95, -99, 59, -25, -79, -84, 93, 88, 77, 72, 37, 21 }, { -23, -27, -18, 52, 62, 20, -42, -98, -62, -17, -69, 9, -53, -27, 13, 34, 41, -15, 41, -76, 8, -45, -25, 17, 8, 32, 9, -22, -83, 99 }, { -90, 37, 81, 28, 86, -3, 50, 62, 11, -88, 22, -55, 25, 11, 69, -51, -73, 48, 2, -42, -53, -8, -69, 13, -87, -78, 98, 65, -57, -71 } };

            int maxSum = GetMaxColumnSum(numbers, out string sumOfColumns);
            Console.WriteLine(sumOfColumns + "are the sum of Absolute values of columns \nHighest is " + maxSum);
        }

        static int GetMaxColumnSum(int[,] numbers, out string sumOfColumns)
        {
            int maxSum = 0;
            int sum = 0;
            int rows = numbers.GetLength(0);
            int cols = numbers.GetLength(1);
            sumOfColumns = "";

            for (int i = 0; i < cols; i++)
            {
                for (int j = 0; j < rows; j++)
                {
                    sum += Math.Abs(numbers[j, i]);
                }
                sumOfColumns += sum + " , ";

                if (maxSum < sum)
                {
                    maxSum = sum;
                }
                sum = 0;
            }

            return maxSum;
        }
        static void ProcessQuestion3()
        {
            Console.WriteLine("Enter string for Questions 3: ");
            string input = Console.ReadLine();
            
            string sb =input;  // Create a StringBuilder to modify the input string

            int i = 0;  // Index to search for pairs from the start
            //int j = sb.Length - 1;  // Index to search for pairs from the end
            
            
            for (; i < (sb.Length-2); i++)
            {
                for (int j = sb.Length - 1; j >i; j--)
                {
                   
                    
                    if (sb[i] == sb[j])
                    {
                        
                        sb=sb.Remove(j, 1);
                        sb=sb.Remove(i,1);
                        if (i > 1)
                        {
                            i = i - 2;
                        }
                        else
                        {
                            i--;
                        }


                        break;
                    }
                }
                
            }
            Console.WriteLine(sb);
        } 



           static void Main(string[] args)
        {

            bool isflag1 = true;
           
            while (isflag1)
            {
                Console.WriteLine("My Assignment");

                //question 3 functions
                ProcessQuestion3();

                //question 4 functions
                ProcessQuestion4();

                //question 5 functions
                ProcessQuestion5();

                //question 6 functions
                ProcessQuestion6();

                //question 7 functions
                ProcessQuestion7();


                Console.WriteLine("\n\n");
                Console.WriteLine("Do You want to exit from here?(Yes/No)");
                string s=Console.ReadLine(); 
                
                if (s == "Yes" || s == "YEs" || s=="YES" || s=="yES" || s=="yes")
                
                {isflag1 = false;}
                else {Console.Clear();}
            }
        }





    }
}
